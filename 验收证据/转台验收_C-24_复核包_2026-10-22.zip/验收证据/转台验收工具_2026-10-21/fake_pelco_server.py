#!/usr/bin/env python3
"""离线假 Pelco-D 设备（仅用于验收工具的离线验证，不是实机证据）。

- 监听 127.0.0.1:6666（可用 argv[1] 改端口）。
- 查询 0x51/0x53 回复当前角度；0xE0 回复与查询逐字节相同（EchoOnly）。
- 绝对定位帧（0x4B/0x4D）原样回显，并设置目标角。
- 每次水平查询推进两轴各 0.4°（模拟运动），停止帧把目标设为当前角。
- 停止帧不回显，与真实设备及测试替身一致。

⚠ 本脚本只证明“工具/会话在离线闭环中的行为”，不证明任何实机特性。
"""
import socket
import struct
import sys

HOST = "127.0.0.1"
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 6666
STEP_DEG = 0.4


def checksum(frame):
    return sum(frame[1:6]) & 0xFF


def build(addr, d1, d2, d3, d4):
    body = bytes([addr, d1, d2, d3, d4])
    return bytes([0xFF]) + body + bytes([sum(body) & 0xFF])


def az_raw(deg):
    d = deg % 360.0
    raw = round(d * 100.0)
    if raw >= 36000:
        raw -= 36000
    return raw & 0xFFFF


def el_raw(deg):
    raw = round(deg * 100.0)
    return raw & 0xFFFF


def raw_to_az(raw):
    deg = raw / 100.0
    return deg - 360.0 if deg > 180.0 else deg


def raw_to_el(raw):
    return raw / 100.0 if raw < 32768 else (raw - 65536) / 100.0


class Device:
    def __init__(self):
        self.az = 0.0
        self.el = 0.0
        self.taz = 0.0
        self.tel = 0.0
        self.moving = False

    def step(self):
        if not self.moving:
            return
        for axis in ("az", "el"):
            cur = getattr(self, axis)
            tgt = getattr(self, "t" + axis)
            delta = tgt - cur
            if abs(delta) <= STEP_DEG:
                setattr(self, axis, tgt)
            else:
                setattr(self, axis, cur + (STEP_DEG if delta > 0 else -STEP_DEG))
        if abs(self.az - self.taz) < 1e-9 and abs(self.el - self.tel) < 1e-9:
            self.moving = False

    def handle(self, data):
        if len(data) != 7 or data[0] != 0xFF:
            return None
        addr, d1, d2, d3, d4 = data[1], data[2], data[3], data[4], data[5]
        if d1 == 0x00 and d2 == 0x51:
            self.step()
            return build(addr, 0x00, 0x59, (az_raw(self.az) >> 8) & 0xFF,
                         az_raw(self.az) & 0xFF)
        if d1 == 0x00 and d2 == 0x53:
            raw = el_raw(self.el)
            return build(addr, 0x00, 0x5B, (raw >> 8) & 0xFF, raw & 0xFF)
        if d1 == 0xE0:
            return bytes(data)  # 逐字节回声 → WorkModeTrust=EchoOnly
        if d1 == 0x00 and d2 in (0x4B, 0x4D):
            raw = (d3 << 8) | d4
            if d2 == 0x4B:
                self.taz = raw_to_az(raw)
            else:
                self.tel = raw_to_el(raw)
            self.moving = True
            return bytes(data)  # 回显
        if d1 == 0x00 and d2 == 0x00 and d3 == 0x00 and d4 == 0x00:
            self.taz = self.az
            self.tel = self.el
            self.moving = False
            print("STOP_FRAME_RECEIVED az=%.3f el=%.3f" % (self.az, self.el),
                  flush=True)
            return None
        return None


def main():
    dev = Device()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind((HOST, PORT))
    print("FAKE_PELCO_LISTEN %s:%d" % (HOST, PORT), flush=True)
    while True:
        data, peer = sock.recvfrom(2048)
        reply = dev.handle(data)
        if reply is not None:
            sock.sendto(reply, peer)


if __name__ == "__main__":
    main()
