#!/usr/bin/env bash
# C-24 验收工具离线复跑（假设备，仅证明工具/会话行为，不是实机证据）
set -u
DIR="$(cd "$(dirname "$0")" && pwd)"
TOOL=/media/hjm/uosData1/proj/proj_plane/AircraftPoseSystem/build-native-off/turntable_acceptance
cd "$DIR"

start_fake() {
    python3 fake_pelco_server.py > "$1" 2>&1 &
    FAKE_PID=$!
    sleep 0.4
}
stop_fake() {
    kill "$FAKE_PID" 2>/dev/null
    wait "$FAKE_PID" 2>/dev/null
}

# A: 配置目录缺失
"$TOOL" --config /nonexistent-config > offline_A_config_missing.log 2>&1
echo "A exit=$?"

# B: 许可缺键
"$TOOL" --config config_loopback --permit permit_offline_missing_key.txt > offline_B_permit_missing_key.log 2>&1
echo "B exit=$?"

# C: 许可设备不匹配
"$TOOL" --config config_loopback --permit permit_offline_wrong_device.txt > offline_C_permit_wrong_device.log 2>&1
echo "C exit=$?"

# D: 许可过期
"$TOOL" --config config_loopback --permit permit_offline_expired.txt > offline_D_permit_expired.log 2>&1
echo "D exit=$?"

# E: 只读 + 无设备
"$TOOL" --config config_loopback --observe-ms 1500 > offline_E_readonly_no_device.log 2>&1
echo "E exit=$?"

# F: 只读 + 假设备
start_fake offline_F_fake_server.log
"$TOOL" --config config_loopback --observe-ms 3000 > offline_F_readonly_fake.log 2>&1
echo "F exit=$?"
stop_fake

# G: 许可 + 运动中停止
start_fake offline_G_fake_server.log
{ sleep 0.4; echo "move az 1.0"; sleep 1.2; echo "move az 5.0"; sleep 0.25; echo "stop"; sleep 1.0; echo "quit"; } \
    | "$TOOL" --config config_loopback --permit permit_offline_valid.txt > offline_G_permit_move_stop.log 2>&1
echo "G exit=$?"
stop_fake

# H: 许可 + 越界/位移超限/NaN
start_fake offline_H_fake_server.log
{ sleep 0.4; echo "move az 20.0"; sleep 0.5; echo "move az 100.0"; sleep 0.5; echo "move az nan"; sleep 0.4; echo "quit"; } \
    | "$TOOL" --config config_loopback --permit permit_offline_valid.txt > offline_H_permit_reject.log 2>&1
echo "H exit=$?"
stop_fake

# I: 次数用尽 + 静止停止
start_fake offline_I_fake_server.log
{ sleep 0.4; echo "move az 1.0"; sleep 1.2; echo "move az 2.0"; sleep 0.8; echo "stop"; sleep 0.4; echo "quit"; } \
    | "$TOOL" --config config_loopback --permit permit_offline_exec1.txt > offline_I_permit_exec_once.log 2>&1
echo "I exit=$?"
stop_fake

# J: 许可 + 静止停止（T1 离线预演）
start_fake offline_J_fake_server.log
{ sleep 0.5; echo "stop"; sleep 0.5; echo "quit"; } \
    | "$TOOL" --config config_loopback --permit permit_offline_valid.txt > offline_J_permit_stop_at_rest.log 2>&1
echo "J exit=$?"
stop_fake

# M: 许可 + 静止状态**实际发送**停止帧（T1 离线预演）
start_fake offline_M_fake_server.log
{ sleep 0.5; echo "stop_at_rest"; sleep 0.8; echo "stop_at_rest"; sleep 0.3; echo "quit"; } \
    | "$TOOL" --config config_loopback --permit permit_offline_valid.txt > offline_M_stop_at_rest_sends.log 2>&1
echo "M exit=$?"
stop_fake

# N: 许可未授权 allow_stop_at_rest ⇒ 静止停止帧零帧
start_fake offline_N_fake_server.log
{ sleep 0.5; echo "stop_at_rest"; sleep 0.4; echo "quit"; } \
    | "$TOOL" --config config_loopback --permit permit_offline_no_stop_at_rest.txt > offline_N_stop_at_rest_denied.log 2>&1
echo "N exit=$?"
stop_fake

# O: 只授权静止停止帧（allow_absolute_position=0）⇒ T1 可发 1 帧，
#    绝对定位始终被拒且不再增加控制帧
start_fake offline_O_fake_server.log
{ sleep 0.5; echo "stop_at_rest"; sleep 0.5; echo "move az 1.0"; sleep 0.5; echo "quit"; } \
    | "$TOOL" --config config_loopback --permit permit_offline_stop_only.txt > offline_O_stop_only_permit.log 2>&1
echo "O exit=$?"
stop_fake

# K: 运动中 SIGINT（现场 Ctrl-C 预演）
start_fake offline_K_fake_server.log
FIFO="$DIR/.k_fifo"
rm -f "$FIFO"
mkfifo "$FIFO"
"$TOOL" --config config_loopback --permit permit_offline_valid.txt \
    < "$FIFO" > offline_K_sigint_stop.log 2>&1 &
TOOL_PID=$!
exec 3>"$FIFO"
echo "move az 5.0" >&3
sleep 0.25
kill -INT "$TOOL_PID" 2>/dev/null
exec 3>&-
wait "$TOOL_PID"
echo "K exit=$?"
rm -f "$FIFO"
stop_fake

# L: 往返重复定位（验证 REPEAT 按目标分组，不混合 A/B）
start_fake offline_L_fake_server.log
{ sleep 0.4; echo "move az 1.0"; sleep 1.0; echo "move az 0.0"; sleep 1.0; \
  echo "move az 1.0"; sleep 1.0; echo "move az 0.0"; sleep 1.0; \
  echo "move az 1.0"; sleep 1.0; echo "quit"; } \
    | "$TOOL" --config config_loopback --permit permit_offline_valid.txt > offline_L_repeat_grouping.log 2>&1
echo "L exit=$?"
stop_fake
